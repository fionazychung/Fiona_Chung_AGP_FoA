﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.EventSystems;

public class DraggableCard : MonoBehaviour, IBeginDragHandler, IDragHandler, IEndDragHandler
{
    private Vector3 returnPosition;
    private CanvasGroup cvGroup;
    PlayerCardUsageSystem playerCardSystem;
    //private playerCardUsageSystem playerCardUsageSystem;

    // Start is called before the first frame update
    void Start()
    {
        cvGroup = GetComponent<CanvasGroup>();
        playerCardSystem = transform.parent.GetComponent<PlayerCardUsageSystem>();

    }

    // Update is called once per frame
    void Update()
    {
        
    }

    public void OnBeginDrag(PointerEventData eventData)
    {
        playerCardSystem.selectedCard = GetComponent<CardDisplay>().card;
        returnPosition = transform.position;
        cvGroup.blocksRaycasts = false;
    }

    public void OnDrag(PointerEventData eventData)
    {
        transform.position = new Vector3(transform.position.x, eventData.position.y, transform.position.z);
    }
    public void OnEndDrag(PointerEventData eventData)
    {
        playerCardSystem.PlayCard();
        playerCardSystem.selectedCard = null;

        playerCardSystem.selectedCard = null;
        cvGroup.blocksRaycasts = true;
        transform.position = returnPosition;
    }
}
