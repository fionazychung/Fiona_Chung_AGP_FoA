﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCardUsageSystem : MonoBehaviour
{
    [SerializeField]
    private PlayerHandZone playerHand;
    public Card selectedCard;
    public CardDisplay cardDisplay;

    public bool cardHasLeftPlayerHandZone = false;

    public void PlayCard()
    {
        if (cardHasLeftPlayerHandZone)
        {
            cardDisplay.CopyCard(selectedCard);

        }
    }




}
