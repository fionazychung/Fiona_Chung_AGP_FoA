﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HandScript
{
    public HandScript()
    {
        hand = new List<GameObject>();
        maxHandSize = 4;
    }

    private List<GameObject> hand;
    private int maxHandSize;

    public void addCard(GameObject card)
    {
        hand.Add(card);
    }
    public int getMaxHandSize()
    {
        return maxHandSize;
    }
    

}
